import React from "react";

const Login = () => {
  return (
    <>
      <h1>Halaman Login</h1>
    </>
  );
};

export default Login;
