import React from "react";

const Register = () => {
  return (
    <>
      <h1>Halaman Register</h1>
    </>
  );
};

export default Register;
