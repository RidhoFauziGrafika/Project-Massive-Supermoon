import React from "react";
import SecondNavbar from "../../component/Navbar/SecondNavbar";
import MainFooter from "../../component/Footer/MainFooter";


const Kontak = () => {
  return (
    <>
      <SecondNavbar />
      <h1>Halaman Kontak</h1>

      <MainFooter />
    </>
  );
};

export default Kontak;
